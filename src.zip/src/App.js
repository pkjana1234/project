import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Navbar from './Components/Common/Navbar';
import Topbar from './Components/Common/Topbar';
import Home from './Pages/Home';
import Footer from './Components/Common/Footer';
import ContactMain from './Pages/ContactMain';
import ServiceMain from './Pages/ServiceMain';
import './index.css';
import BasicSingleService from './Homes/BasicSingleService';
import MainSingleservice from './Homes/MainSingleservice';  
import Login from './Pages/Login'
import Register from './Pages/Register'
function App() {
  return (
    <>
      <Router>
        <Topbar />
        <Navbar />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/contact' element={<ContactMain />} />
          <Route path='/service' element={<ServiceMain />} />
          <Route path='/login' element={<Login/>} />
          <Route path='/register' element={<Register/>} />
          <Route path='/service/:id' element={<BasicSingleService/>} />
          <Route path='/mainservice/:id' element={<MainSingleservice/>} />
        </Routes>
        <Footer />
      </Router>

    </>
  );
}

export default App;
