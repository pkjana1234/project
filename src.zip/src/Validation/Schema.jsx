import * as Yup from 'yup'

export const RegisterSchema = Yup.object({
    fname : Yup.string().min(2).max(10).required("Please Enter Your First Name"),
    lname : Yup.string().min(2).max(10).required("Please Enter Your Last Name"),
    email : Yup.string().email().required("Please Enter Your Email Address"),
    phone : Yup.number().required("Please Enter Your Mobile Number"),
    password : Yup.string().min(6).max(12).required("Please Enter Your Password")
})