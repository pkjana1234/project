import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import AuthInstance from '../../ApiBuild/AuthInstance'

export const RegisterApi = createAsyncThunk('api/register', async (data) => {
    try {
        const res = await AuthInstance.post("users", data)
        return res?.data
    } catch (error) {
        console.log(error);
    }
})
export const UsersApi = createAsyncThunk('api/users', async()=>{
    const res = await AuthInstance.get('users')
    return(res?.data)
})
export const AuthSlice = createSlice({
    name: "AuthApis",
    initialState: {
        data: [],
        loading: false,
        loginToggle: ''
    },
    reducers: {
        redirectTo: (state, { payload }) => {
            state.loginToggle = ''
        }
    },
    extraReducers: {
        [RegisterApi.pending]: (state, { payload }) => {
            state.loading = true
        },
        [RegisterApi.fulfilled]: (state, { payload }) => {
            state.loading = false
            // state.data = payload
            alert(payload?.fname)
            state.loginToggle = "/login"
            console.log("RegisterApi fulfilled");
        },
        [RegisterApi.rejected]: (state, { payload }) => {
            state.loading = false
            console.log("RegisterApi failed on load");
        },
        //usersapi fetch
        [UsersApi.pending]: (state, {payload}) => {
            state.loading = true
        },
        [UsersApi.fulfilled]: (state, {payload}) =>{
            state.loading = false
            state.data=payload
        },
        [UsersApi.rejected]: (state,{payload}) =>{
            state.loading = false
        }
    }
})
export const { redirectTo } = AuthSlice.actions