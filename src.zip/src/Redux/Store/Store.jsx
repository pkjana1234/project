import { configureStore } from "@reduxjs/toolkit";
import { BannerSlice } from "../Slices/HomeDataSlice";
import { AuthSlice } from "../Slices/AuthSlice";


const store = configureStore({
    reducer :{
        Banner : BannerSlice.reducer,
        Auth : AuthSlice.reducer
    }
})
export default store