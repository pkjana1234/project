import { useFormik } from 'formik'
import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { redirectTo } from '../Redux/Slices/AuthSlice'

const initial = {
    email: '',
    password: ''
}
const Login = () => {
    const dispatch = useDispatch()
    const { } = useSelector((state) => {
        console.log(state);
        return state
    })
    const { values, handleChange, handleBlur, handleSubmit, errors, touched } = useFormik({
        initialValues: initial,
        onSubmit: (value) => {
            console.log(value);
        }
    })
    const handelClick = () => {
        dispatch(redirectTo())
    }
    return (
        <>
            <div class="container-fluid my-5 px-0">
                <div class="container position-relative wow fadeInUp" data-wow-delay="0.1s" style={{ marginTop: "6rem" }}>
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="bg-light text-center p-5">
                                <h1 class="mb-4">Login Account</h1>
                                <form onSubmit={handleSubmit}>
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <input type="email" class="form-control border-0" onChange={handleChange} onBlur={handleBlur} value={values.email} placeholder="Your Email" style={{ height: "55px" }} name='email' />
                                        </div>
                                        <div class="col-12">
                                            <input type="password" class="form-control border-0" onChange={handleChange} onBlur={handleBlur} value={values.password} placeholder="Password" style={{ height: "55px" }} name='password' />
                                        </div>
                                        <p className='text-start'>Don't have any account? <Link to='/register' onClick={handelClick}>click here</Link></p>
                                        <div class="col-12">
                                            <button class="btn btn-primary w-100 py-3" type="submit">Log In</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Login