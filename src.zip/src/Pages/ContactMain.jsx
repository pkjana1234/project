import React from 'react'
import Contact from '../Components/Contact/Contact'
import ContactBanR from '../Components/Contact/ContactBanR'
// import ContactNav from '../Components/Contact/ContactNav'
const ContactMain = () => {
  return (
    <>
    <ContactBanR/>
    <Contact/>
    {/* <ContactNav/> */}
    </>
  )
}

export default ContactMain