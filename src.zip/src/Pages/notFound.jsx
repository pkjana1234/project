import React from 'react'

const notFound = () => {
  return (
    <div>404notFound</div>
  )
}

export default notFound